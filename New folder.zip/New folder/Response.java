import java.util.ArrayList;
import java.util.List;


public class Response 
{
	List<Vehicle> vehicleObjectList = new ArrayList<Vehicle>();
	String output = null;
	boolean success = false;
}
