/*Class to print vehicle details.
 * @author parul 
 * */
public class VehiclePrinter 
{
	/*Function prints vehicle details.
	 * It takes vehicle object as key parameter.
	 * It return a string specifying vehicle details.*/
	public static String printVehicleSpecification(Vehicle objectVehicle) 
	{
		return objectVehicle.toString();
	}

}
