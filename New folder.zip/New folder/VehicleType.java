
public enum VehicleType {
	Car,Bike;
}
